﻿using System;
using System.Collections.Generic;
using System.Text;
using Moq;
using ClueGoASP.Services;

namespace XUnitTestClueGo
{
    class UserServiceMock
    {

        //public IUserService UserServiceMock(IUserService service )
        //{
        //    var service = service ??  Mock.Of<IUserService>();

        //    return new UserService(service);
        //}

    }
}
