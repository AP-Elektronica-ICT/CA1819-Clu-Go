using ClueGoASP.Data;
using ClueGoASP.Models;
using ClueGoASP.Services;
using System;
using Xunit;
using System.Collections.Generic;
using ClueGoASP.Helper;
using Microsoft.EntityFrameworkCore;
using Moq;

namespace XUnitTestClueGo
{
    public class PrimeService_UserController
    {
        User fakeUser = new User();
        private static UserService userService;
        private static readonly GameContext gameContext;

        static PrimeService_UserController()
        {
            userService = Mock.Of<UserService(new GameContext())>();


           // userService = new UserService(gameContext);



        }

        [Fact]
        public void ValidateUsername()
        {
            //Arrange
            fakeUser.Username = "henk";
            fakeUser.Password = "123456";
            //Act
            //User response = userService.Login(fakeUser.Username, fakeUser.Password);
            var userLogintest = userService.Login(fakeUser.Username, fakeUser.Password); //new UserService(gameContext);


            //Assert
            //Assert.Throws<AppException>(() => userLogintest.Login("", "123456"));
            Assert.Equal(fakeUser, userLogintest);
        }
    }
}
